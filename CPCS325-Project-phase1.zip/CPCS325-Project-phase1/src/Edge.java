
/**
 * @author lujain Abdullah
 */

//-----------------class Edge ---------------------------------
public class Edge {
     //-------------------variables----------------------
   private  int  weight;
  private   Vertex parent ; 
  private   Vertex Source; 
  private   Vertex Target;
  //-----------------------------------------------------
  
 // ---------------------constructers--------------------
       public Edge(Vertex Source, Vertex Target , int weight) {
        this.weight = weight;
        this.Source = Source;
        this.Target = Target;
    }
       public Edge(Vertex parent,int weight) {
         this.weight = weight;
        this.parent = parent;
    }

    public Edge(Vertex t) {
        this.weight = 0;
        this.Source = t;
        this.Target = t;
        this.parent = t;
    }

    public Edge() {
    }
 //-----------------------------------------------------
    
//--------------------------- Method---------------------
  public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public Vertex getParent() {
        return parent;
    }

    public void setParent(Vertex parent) {
        this.parent = parent;
    }

    public Vertex getSource() {
        return Source;
    }

    public void setSource(Vertex Source) {
        this.Source = Source;
    }

    public Vertex getTarget() {
        return Target;
    }

    public void setTarget(Vertex Target) {
        this.Target = Target;
    }
 //-----------------------------------------------------
}
 //---------------------END Class--------------------------------
