
/**
 * @author lujain Abdullah
 */
// importing packeges
import java.util.LinkedList;
//---------------Graph Class----------------------------------------

public class Graph {

    //-------------------- variables---------------------------------
    private int verticesNo;
    private int edgeNo;
    private boolean isDigraph;
    //an array  for all verteces 
    private Vertex[] vertices = null;
    //an array for all edges 
    private Edge edge[] = null;

   //-----------------------------------------------------------------
    // --------------------constructers--------------------------------
    public Graph(int verticesNo, int edgeNo, boolean isDigraph) {
        this.verticesNo = verticesNo;
        this.edgeNo = edgeNo;
        this.isDigraph = isDigraph;
        edge = new Edge[edgeNo];
        makeGraph(verticesNo, edgeNo);
    }
//----------------------------------------------------------------------

    // ---------------------Methods-------------------------------------
    // method to creat the verteces and generate random weight
    public void makeGraph(int verticesNo, int edgeNo) {
        // declare and cerate the array for list of vertices 
        vertices = new Vertex[verticesNo];
        //System.out.println(edgeNo);
        //-----------Vertex--------------------
        //initialize the array  for all the vertices
        for (int i = 0; i < vertices.length; i++) {

            // number for vertex 
            int r = i + 1;

            // creating a vertex opject
            Vertex v = new Vertex(i, false);

            // adding the vertex to the array 
            vertices[i] = v;

        }  //End for 

        //-----------Edge--------------------
        // creating edges for each vertex randomely 
        // initialize the array of edges 
        // counter for edges 
        int edges = 0;
        //1- connect all vertex together 
        for (int i = 0; i < vertices.length - 1; i++) {
            Vertex s = vertices[i];
            Vertex t = vertices[i + 1];
            int wt = (int) (Math.random() * 500);
            Edge e = new Edge(s, t, wt);
            edge[i] = e;
            edges++;
            // calling the method add e2 to add the e2 to the list for vertex
            this.addEdge(s, t, wt);

        }//end for 
        //-------------------------------------------------
        //connecting tha last vertex with the first one
        Vertex s = vertices[vertices.length - 1];
        Vertex t = vertices[0];
        int wt = (int) (Math.random() * 500);
        Edge e = new Edge(s, t, wt);
        edge[edges] = e;
        edges++;
        // calling the method add e2 to add the e2 to the list for vertex
        this.addEdge(s, t, wt);
        //-------------------------------------------------

        //loop to insure that the number of generated edges is equal the requested number
        while (edges != edgeNo) {

            // 2- generate random source and target 
            int rand1 = (int) (Math.random() * verticesNo);
            int rand2 = (int) (Math.random() * verticesNo);
            //3- chack if the e2 is exsist or not
            int check = 0;
            for (int i = 0; i < edges; i++) {
                if (rand1 == rand2) {
                    check = 1;
                }
                if (edge[i].getSource().getLabel() == rand1 && edge[i].getTarget().getLabel() == rand2) {
                    check = 1;
                }
                if (edge[i].getSource().getLabel() == rand2 && edge[i].getTarget().getLabel() == rand1) {
                    check = 1;
                }
            }//end for

            // 4- generate the e2 
            if (check == 0) {
                s = vertices[rand1];
                t = vertices[rand2];
                wt = (int) (Math.random() * 500);
                e = new Edge(s, t, wt);
                edge[edges] = e;
                edges++;
                // calling the method add e2 to add the e2 to the list for vertex
                this.addEdge(s, t, wt);
            }// end if 
        }//end while 

    }//End Method 

//----------------------------------------------------------------------------------------------
    //method to add the edges to the source and target verteces 
    public void addEdge(Vertex Source, Vertex Target, int w) {
        // Undirected graph
        // for source vertex 
        // creating an e2 object
        Edge e = new Edge(Source, Target, w);
        // adding the e2 to the source vertex list 
        LinkedList<Edge> SourceList = Source.getAdjList();
        SourceList.addLast(e);

        // for target vertex 
        Edge e2 = new Edge(Target, Source, w);
        // adding the e2 to the source vertex list 
        LinkedList<Edge> TargetList = Target.getAdjList();
        int c = 0;
        for (int i = 0; i < TargetList.size(); i++) {
            if (TargetList.get(i).getTarget().getLabel() == Source.getLabel()) {
                c = 1;
            }
        }
        if (c == 0) {
            TargetList.addLast(e2);
        }

        if (isDigraph == true) {
            edgeNo++;
        } else {
            edgeNo = edgeNo + 2;
        }

    }// End Method
//---------------------------------------------------------------------------------
    //method to print all vereteces and thier edges 

    public void print(Vertex[] adjacencylist) {
        for (int i = 0; i < adjacencylist.length; i++) {
            Vertex source = adjacencylist[i];
            System.out.print("[" + source.getLabel() + "]  ");
            LinkedList<Edge> List = source.getAdjList();
            for (int j = 0; j < List.size(); j++) {
                System.out.print(List.get(j).getTarget().getLabel() + " ... w= " + List.get(j).getWeight() + "   ");
            }
            System.out.println("");
        }
    }//end method
    //--------------------------------------------------------------------------------
    //method search for an edge by source and target verteces and return it 

    public Edge getEdge(int source, int target) {
        for (int j = 0; j < this.getEdge().length; j++) {
            Edge e = this.getEdge()[j];
            if (e.getSource().getLabel() == source && e.getTarget().getLabel() == target || e.getSource().getLabel() == target && e.getTarget().getLabel() == source) {
                return e;
            }
        }
        return null;
    }//end method 
    //---------------------------------------------------------------------------------
    //method search for an edge by weigth and return it 

    public Edge getEdge(int W) {
        for (int j = 0; j < this.getEdge().length; j++) {
            Edge e = this.getEdge()[j];
            if (e.getWeight() == W) {
                return e;
            }
        }
        return null;
    }//end method
//--------------------------------------------------------------------------------------
    //method to search and return the vertex 

    public Vertex getVertex(int node) {
        for (int j = 0; j < this.getEdge().length; j++) {
            Edge e = this.getEdge()[j];
            if (e.getSource().getLabel() == node) {
                return e.getSource();
            }
        }
        return null;
    }//end method 
    //method to get the list of edges for a spesific vertex 

    public LinkedList<Edge> getAdjacencylist(int vertex) {
        for (int i = 0; i < vertices.length; i++) {
            if (vertices[i].getLabel() == vertex) {
                return vertices[i].getAdjList();
            }
        }

        return vertices[0].getAdjList();
    }//end method 
    //-----------------------------------------------------------------------------------
    //setter and getter methods 

    public int getVerticesNo() {
        return verticesNo;
    }

    public void setVerticesNo(int verticesNo) {
        this.verticesNo = verticesNo;
    }

    public int getEdgeNo() {
        return edgeNo;
    }

    public void setEdgeNo(int edgeNo) {
        this.edgeNo = edgeNo;
    }

    public boolean isIsDigraph() {
        return isDigraph;
    }

    public void setIsDigraph(boolean isDigraph) {
        this.isDigraph = isDigraph;
    }

    public Vertex[] getVertices() {
        return vertices;
    }

    public void setVertices(Vertex[] vertices) {
        this.vertices = vertices;
    }

    public Edge[] getEdge() {
        return edge;
    }

    public void setEdge(Edge[] edge) {
        this.edge = edge;
    }
}//End class
//---------------------------------------------------------------------------------------
