
/**
 * @author lujain Abdullah
 */

// importing packeges
import java.util.LinkedList;

//---------------MSTAlgorithm Class----------------------------------------
public class MSTAlgorithm {

    //-------------------------variables-----------------------------------

     Graph graph;
     LinkedList<Edge> MSTresultList;
//-------------------------------------------------------------------------
    //-------------------------constructers--------------------------------
    public MSTAlgorithm(Graph graph) {
        MSTresultList = new LinkedList<>();
        this.graph = graph;

    }
//----------------------------------------------------------------------------
    // --------------------------methods------------------------------------
    // abstract function that should be implemented by the subclasses’ polymorphic functions.
    public String displayResultingMST() {
        return " ";
    }
//--------------------------------------------------------------------------
    //setter and getter methods 
    public Graph getGraph() {
        return graph;
    }
    public void setGraph(Graph graph) {
        this.graph = graph;
    }

    public LinkedList<Edge> getMSTresultList() {
        return MSTresultList;
    }

    public void setMSTresultList(LinkedList<Edge> MSTresultList) {
        this.MSTresultList = MSTresultList;
    }
//-----------------------------------------------------------------------------
}//end class 
//-----------------------------------------------------------------------------

//----------------------------Heap Node Class-----------------------------------
//used in priority queue prim 
class HeapNode {
    int vertex;
    int key;
}
