
/**
 * @author lujain Abdullah
 */
// importing packeges
import java.util.Arrays;

//---------------KruskalAlg Class----------------------------------------
public class KruskalAlg extends MSTAlgorithm {

    // ---------------------------constructer-----------------------------------
    public KruskalAlg(Graph graph) {
        super(graph);
    }
//-------------------------------------------------------------------------------
    //-----------------------------methods---------------------------------------
    // polymorphic method 

    public String displayResultingMST(Graph graph) {
        //variable to save the starting time 
        Long Start = System.nanoTime();
        //variable to Cost the cost 
        int Cost = 0;
        //variable for the number of verteces 
        int v = graph.getVerticesNo();

        //array to save the edges 
        Edge result[] = new Edge[v];

        // counter for the edges 
        int e = 0;
        //loop to inialize the result edges 
        for (int i = 0; i < v; ++i) {
            result[i] = new Edge();
        }//end for 

        // variable for the number of edges in the graph
        int len = super.getGraph().getEdge().length;

        //#2 creating the array of wieght 
        int[] edge = new int[len];
        //#3 getting the array of edges 
        Edge d[] = super.getGraph().getEdge();
        // for loop to get the wieght
        for (int n = 0; n < len; n++) {
            edge[n] = d[n].getWeight();
        }//end for 
        // Sorting the edges
        Arrays.sort(edge);

        // set array to check if there is a cycle or not 
        subset subsets[] = new subset[v];
        for (int i = 0; i < v; ++i) {
            subsets[i] = new subset();
        }
        // loop to initialize the set 
        for (int L = 0; L < v; ++L) {
            subsets[L].parent = L;
            subsets[L].rank = 0;
        }

        // counter 
        int i = 0;
        //loop to go over all verteces  
        while (e < v - 1 && i < len) {
            Edge next_edge = new Edge();
            Edge nod = graph.getEdge(edge[i++]);
            next_edge = nod;
            // call fine method to check if there is cycle 
            int x = find(subsets, next_edge.getSource().getLabel());
            int y = find(subsets, next_edge.getTarget().getLabel());
            if (x != y) {
                result[e++] = next_edge;
                Union(subsets, x, y);
            }
        }//end loop 

        //loop to add the result edges to MSTresultList and calculate the cost of the tree 
        for (int j = 0; j < result.length; j++) {
            super.getMSTresultList().add(result[j]);
            Cost += result[j].getWeight();
        }//end for 

        //variable to save the end time 
        Long End = System.nanoTime();

        //printing the cost 
        System.out.println("The Cost Of Minimum Spanning Tree is: " + Cost);
        //printing the running time 
        System.out.println("The Time For Executing Kruskal Algorithm is: " + (End - Start));
        return "";
    }
    //end method 
//---------------------------------------------------------------------------------------------------------

//------------------methods-------------------------------
    //method to find the the set 
    int find(subset subsets[], int i) {
        if (subsets[i].parent != i) {
            subsets[i].parent = find(subsets, subsets[i].parent);
        }
        return subsets[i].parent;
    }//end method 
    //----------------------------------------------------------
//method to make union of two set 

    void Union(subset subsets[], int x, int y) {
        int xroot = find(subsets, x);
        int yroot = find(subsets, y);

        if (subsets[xroot].rank < subsets[yroot].rank) {
            subsets[xroot].parent = yroot;
        } else if (subsets[xroot].rank > subsets[yroot].rank) {
            subsets[yroot].parent = xroot;
        } else {
            subsets[yroot].parent = xroot;
            subsets[xroot].rank++;
        }
    }//end method
    //----------------------------------------------------------------

    //method to print the edges of the minimum spanning tree 
    public void print(Edge[] e) {
        for (int i = 0; i < e.length; i++) {
            Edge edge = e[i];
            System.out.print("[" + edge.getSource().getLabel() + "]----[  " + edge.getTarget().getLabel() + "]  " + edge.getWeight());

            System.out.println("");
        }
    }//end method

}//end class
//---------------------------------------------------------------------------------
//------------Class subset ----------------------------------------------------------------

class subset {

    int parent, rank;
}//end class
//---------------------------------------------------------------------------------

